export const modules = [
  {
    name: "tritation",
    image: null,
  },
  {
    name: "distilation",
    image: null,
  },
];
