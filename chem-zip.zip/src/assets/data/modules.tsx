import tritationImg from "../images/modules/tritation.png";
import distilationImg from "../images/modules/distilation.png";

export const modules = [
  {
    name: "Tritation",
    image: tritationImg,
  },
  {
    name: "Distilation",
    image: distilationImg,
  },
];
