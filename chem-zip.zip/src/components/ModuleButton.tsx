import React from "react";
import { ModuleButtonProps } from "../types/types";
import "../styles/moduleButton.scss";

export const ModuleButton: React.FC<ModuleButtonProps> = ({
  label,
  image,
  onClick,
}) => {
  const style = {
    backgroundImage: image ? `url(${image})` : undefined,
    backgroundSize: 'cover',
    backgroundPosition: 'center'
  };

  return (
    <div className="module-button" style={style} onClick={onClick}>
      <button className="module-button__button" >{label}</button>
    </div>
  );
};
