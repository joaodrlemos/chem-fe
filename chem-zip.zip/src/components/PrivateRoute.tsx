import React from 'react';
import { Navigate, Route } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { PrivateRouteProps } from '../types/types';

export const PrivateRoute: React.FC<PrivateRouteProps> = ({ path, element, ...rest }) => {
  const { user } = useAuth();

  return user ? <Route path={path} element={element} {...rest} /> : <Navigate to="/" replace />;
};
