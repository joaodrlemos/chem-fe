# Chem Project

Figma Layout: https://www.figma.com/file/8i9n155zYaW8RFyfmwP6Nq/first--site?type=whiteboard&node-id=506-3426&t=YrOw9Tm4swlSdG4y-0