import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export const LoginPage: React.FC = () => {
    const navigate = useNavigate();
    const { login } = useAuth();
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleLogin = () => {
        login(username, password);
        navigate('/home');
    };

    return (
        <div className="login-container">
            <div className="logo-section">
                <img src="../assets/images/logos/transparent_light_mode.png" alt="Logo" />
                <h1>Welcome to Chem login Page</h1>
            </div>
            <div className="auth-section">
                <div className="auth-form">
                    <input
                        type="text"
                        placeholder="User"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                    />
                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                    <button onClick={handleLogin}>Login</button>
                </div>
            </div>
        </div>
    );
}
