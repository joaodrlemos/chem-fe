export const users = 
[
    {
        "username": "professor",
        "password": "professor",
        "role": "admin",
    },
    {
        "username": "student",
        "password": "student",
        "role": "admin",
    }
];
